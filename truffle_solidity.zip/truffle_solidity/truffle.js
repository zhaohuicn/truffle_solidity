var HDWalletProvider = require("truffle-hdwallet-provider"); 
module.exports = {
//    contracts_build_directory: "./output",
    networks: {
        development: {
          host: "localhost",
          port: 8545,
          network_id: "*"
        },
        ropsten : {
            provider: new HDWalletProvider("below cycle never little depend awkward around peanut defy blouse feel emotion", "https://ropsten.infura.io/5NRy8ReceCtFNg9ZWCUE"),
            network_id: 3,
            gas: 3012388,
            gasPrice: 30000000000
        }
    }
};